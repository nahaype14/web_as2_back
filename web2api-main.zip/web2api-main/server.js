const express = require("express");
const axios = require("axios");
const app = express();

require("dotenv").config();

app.use(express.static("public"));

app.get("/weather", async (req, res) => {
  try {
    const { lat, lon } = req.query;
    const apiKey = process.env.OPENWEATHER_API_KEY;

    // Use a different variable for the axios response
    const weatherResponse = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}`
    );

    const weatherData = weatherResponse.data;
    const airQualityIndex = await getAirQualityIndex(lat, lon);

    res.json({
      ...weatherData,
      airQualityIndex,
    });
  } catch (error) {
    console.error("Error fetching weather data:", error);
    res.status(500).json({
      error: "Internal Server Error",
    });
  }
});

async function getAirQualityIndex(lat, lon) {
  try {
    const openAQApiKey = process.env.OPENAQ_API_KEY;
    const res = await axios.get(
      `https://api.openaq.org/v2/latest?coordinates=${lat},${lon}&apiKey=${openAQApiKey}`
    );

    const data = res.data;

    if (data.results && data.results.length > 0) {
      const value = data.results[0].measurements.find(
        (measurement) => measurement.parameter === "pm25"
      );

      if (value) {
        return value.value;
      } else {
        console.error("Measurement 'pm25' not found in air quality data");
        return "N/A";
      }
    } else {
      console.error("No air quality results found for the specified coordinates");
      return "N/A";
    }
  } catch (error) {
    console.error("Error fetching air quality data:", error);
    return "N/A";
  }
}


app.get("/timezone", async (req, res) => {
  try {
    const { lat, lon, timestamp } = req.query;
    const timezoneApiKey = process.env.TIMEZONE_DB_API_KEY;
    const timezoneResponse = await axios.get(
      `http://api.timezonedb.com/v2.1/get-time-zone?key=${timezoneApiKey}&format=json&by=position&lat=${lat}&lng=${lon}&time=${timestamp}`
    );
    res.json(timezoneResponse.data);
  } catch (error) {
    console.error("Error fetching timezone data:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`Server is up and running at http://localhost:${port}`);
});
