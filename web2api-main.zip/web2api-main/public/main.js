let map;
let timeInterval;

async function getWeather(lat, lon, city) {
  try {
    clearInterval(timeInterval);

    const res = await fetch(`/weather?lat=${lat}&lon=${lon}`);
    const data = await res.json();

    const temperatureCelsius = data.main.temp - 273.15;
    const feelsLikeCelsius = data.main.feels_like - 273.15;

    const timestamp = data.dt;
    const timezoneResponse = await fetch(
      `/timezone?lat=${lat}&lon=${lon}&timestamp=${timestamp}`
    );
    const timezoneData = await timezoneResponse.json();

    const timezone = timezoneData.zoneName;

    const date = new Date(timestamp * 1000);
    const formattedDate = date.toLocaleDateString(undefined, {
      year: "numeric",
      month: "long",
      day: "numeric",
      timeZone: timezone,
    });

    const weatherElement = document.getElementById("weather-info");
    weatherElement.innerHTML = `
      <div class="weather-card w-max px-10 mt-10 py-8 rounded-xl bg-zinc-800 text-white">
        <div class="flex items-center">
          <p>
            ${data.weather[0].description}
          </p>
          <img src="http://openweathermap.org/img/wn/${
            data.weather[0].icon
          }.png" alt="Weather Icon" class="">
        </div>
        <h1 class="text-2xl font-bold mb-2">${data.name}</h1>
        <p>Temperature: <span class="text-blue-500">${temperatureCelsius.toFixed(
          2
        )}°C</span></p>
        <p>Description:  <span class="text-blue-500">${
          data.weather[0].description
        }</span></p>
        
        <p>Coordinates:  <span class="text-blue-500">${data.coord.lat}, ${
      data.coord.lon
    }</span></p>
        <p>Feels Like: <span class="text-blue-500"> ${feelsLikeCelsius.toFixed(
          2
        )}°C</span></p>
        <p>Humidity:  <span class="text-blue-500">${
          data.main.humidity
        }%</span></p>
        <p>Pressure:  <span class="text-blue-500">${
          data.main.pressure
        } hPa</span></p>
        <p>Wind Speed:  <span class="text-blue-500">${
          data.wind.speed
        } m/s</span></p>
        <p>Country Code:  <span class="text-blue-500">${
          data.sys.country
        }</span></p>
        <p>Rain Volume (last 3 hours):  <span class="text-blue-500">${
          data.rain ? data.rain["1h"] : 0
        } mm</span></p>
        <p>Air Quality Index:  <span class="text-blue-500">${
          data.airQualityIndex || "N/A"
        }</span></p>
        <p>Date:  <span class="text-blue-500">${formattedDate}</span></p>
        <p id="current-time" class="text-green-500"></p> <!-- Placeholder for current time -->
        <p>Timezone:  <span class="text-blue-500">${timezone}</span></p>
      </div>
    `;

    showMap("map", data.coord.lat, data.coord.lon, data.name, timezone);

    const currentTimeElement = document.getElementById("current-time");
    timeInterval = setInterval(() => {
      const currentTime = new Date().toLocaleTimeString(undefined, {
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        timeZone: timezone,
        hour12: true,
      });
      currentTimeElement.textContent = `Current Time: ${currentTime}`;
    }, 1000);
  } catch (error) {
    console.error("Error fetching weather data:", error);
  }
}

async function getWeatherByCity() {
  const city = document.getElementById("city").value;

  const res = await fetch(
    `https://nominatim.openstreetmap.org/search?city=${city}&format=json`
  );
  const data = await res.json();

  if (data.length > 0) {
    getWeather(data[0].lat, data[0].lon, city);
  } else {
    alert(`Not found`);
  }
}

async function getTimezone(lat, lon, timestamp) {
  try {
    const res = await fetch(
      `/timezone?lat=${lat}&lon=${lon}&timestamp=${timestamp}`
    );
    const data = await res.json();
    console.log("Timezone:", data);
  } catch (error) {
    console.error("Error when fetching timezone:", error);
  }
}

async function getCurrentLocationWeather() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(async (position) => {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;
      getWeather(lat, lon);
    });
  } else {
    alert("Your browser not support geolocation");
  }
}

async function getWeatherByCoordinates() {
  const lat = document.getElementById("lat").value;
  const lon = document.getElementById("lon").value;

  if (lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    alert(
      "Invalid coordinates, required range:\nLatitude (-90 to 90)\nLongitude (-180 to 180)"
    );
    return;
  }

  const res = await fetch(
    `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`
  );
  const data = await res.json();

  if (!data.address || !data.address.city) {
    alert("No city found for the entered coordinates.");
    return;
  }

  getWeather(lat, lon, data.address.city);
}

function showMap(containerId, lat, lon, cityName) {
  if (!map) {
    map = L.map(containerId).setView([lat, lon], 5);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "Talgatov Aibyn",
    }).addTo(map);
  }

  map.eachLayer((layer) => {
    if (layer instanceof L.Marker) {
      layer.remove();
    }
  });

  L.marker([lat, lon]).addTo(map).bindPopup(`<b>${cityName}</b>`).openPopup();
}

function selectCityOnMap() {
  alert("Click on the map to select a city.");
  map.on("click", (e) => {
    getWeather(e.latlng.lat, e.latlng.lng);
    map.off("click");
  });
}
