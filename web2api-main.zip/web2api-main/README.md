# Weather App Api usage project

A simple weather application that provides weather information based on location.


1. **Install the required npm packages:**

   ```bash
   npm i

## Config

1. **Create a .env file in the root directory of the project.**

2. **Add the following environment variables to the .env file:**
    ```bash
    PORT = 3000
    OPENWEATHER_API_KEY = 751f1880e357af46026e44fa855dd102
    UNSPLASH_API_KEY = SOA6Q1M5Q4FzVBAWGg0JhyNIHjKfqGzbbDljY5GGfJY
    OPENAQ_API_KEY = a27ef85d31480c5cd8036e54d56d14de5a6842415ee9899f24e39605d32836f9
    TIMEZONE_DB_API_KEY = BB5CW5D7IZBX

## Run

1. **Run the application**
    ```bash
       npm run start
    
**The server will be running at http://localhost:3000**


## Usage

1. Go to browser http://localhost:3000.

2. Enter a city name, latitude, and longitude, or use the provided buttons to get weather information.


## Usage of APIs

### 1. OpenWeather API

- **Endpoint:** `/weather`
- **Parameters:**
  - `lat`: Latitude of the location
  - `lon`: Longitude of the location
- **Example Request:**

  ```bash
  curl http://localhost:3000/weather?lat=37.7749&lon=-122.4194

### 2. OpenAirQuality API

- **Function:** `getAirQualityIndex(lat, lon)`
- **Parameters:**
  - `lat`: Latitude of the location
  - `lon`: Longitude of the location
- **Example Request:**

  ```bash
  getAirQualityIndex(37.7749, -122.4194);


### 4. TimezoneDatabase API

- **Endpoint:** `/timezone`
- **Parameters:**
  - `lat`: Latitude of the location
  - `lon`: Longitude of the location
  - `timestamp`: UNIX timestamp
- **Example Request:**

  ```bash
  curl http://localhost:3000/timezone?lat=37.7749&lon=-122.4194&timestamp=1642742400
